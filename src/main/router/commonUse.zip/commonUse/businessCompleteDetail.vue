<template>

</template>

<script>
export default {
    name: 'businessCompleteDetail',
}
</script>

<style lang="sass" scoped>

</style>

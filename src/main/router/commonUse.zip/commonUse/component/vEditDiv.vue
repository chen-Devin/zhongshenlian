<template>
    <div contenteditable="true" v-html="innerText" @input="onDivInput($event)"></div>
</template>
<script>
    export default {
        props: ['value'],
        data(){
            return {innerText:this.value}
        },
        methods:{
           onDivInput: function(e) {
        this.myHtmlCode = e.target.innerHTML;
        //console.log('Text: %o', this.myHtmlCode );
      }
        }
        /*methods:{
            changeText(){
               this.innerText = this.$el.innerHTML;
               this.$emit('input',this.innerText);
            }
        }*/
    }
</script>

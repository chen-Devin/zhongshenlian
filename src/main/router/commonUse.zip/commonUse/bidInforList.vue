<template>

</template>

<script>
export default {
    name: 'bidInforList',
}
</script>

<style lang="sass" scoped>

</style>

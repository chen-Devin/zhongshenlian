<template>
<div class="main">
    <crumbs v-bind:paths="paths"></crumbs>
    <button class="btn btn-primary pull-right" type="button" @click="editRule">编辑</button>
    <card>
      <div v-bind="detail">
        <div v-bind:class="{borderInput: isBorder}" class="inputTitle" v-bind:contenteditable="isActive" @onchange="change()">{{detail.title}}</div>
        <div v-bind:class="{borderInput: isBorder}" class="inputContent" v-bind:contenteditable="isActive">{{detail.content}}</div>
        <div class="ruleBtn" v-bind:class="{hidePart: isHide}">
          <p class="text-right text-muted">{{detail.releaseDepartment}}</p>
          <p class="text-right text-muted">{{detail.releaseTime}}</p>
        </div>
        <div class="ruleBtn" style="display: none" v-bind:class="{showPart: isShow}">
          <button class="btn btn-primary btn-save" type="button" @click="saveEdit()">保存</button>
          <button class="btn btn-default" type="button" @click="canceled()">取消</button>
        </div>
      </div>
   </card>
</div>
</template>

<script>
import axios from 'axios';
import qs from 'qs';
import router from '../index.js';

import crumbs from '../../component/crumbs.vue';
import card from '../../component/card.vue';
export default {
    name: 'ruleRegulationDetail',
    data() {
    	return {
        paths: [
          { name: '制度列表', url: '/rule-regulation', present: false },
          { name: '制度详情', url: `/rule-regulation-detail/${this.$route.params.id}`, present: true }
        ],
        isBorder: false,
        isActive: false,
        isHide: false,
        isShow: false,
        detail: {
           id: this.$route.params.id,
           title: "",
           content: "",
           releaseDepartment: "",
           releaseTime: ""
           //numbering: ""
        }
      }
    },
    created() {
      this.getRuleDetail();
    },
    methods: {
      getRuleDetail(){
         axios({
        method: 'get',
        url: '/service',
        params: {
            data: (()=>{
            var obj = {
                command: 'getRegulationsInfo',
                platform: 'web',
                regulationsId: this.$route.params.id
            }
            return JSON.stringify(obj);
            })()
        },
    }).then((rep) => {
            if (rep.data.statusCode === '10001') {
              this.detail.title =  rep.data.data.title,
              this.detail.content =  rep.data.data.content,
              this.detail.releaseDepartment = rep.data.data.releaseDepartment,
              this.detail.releaseTime = rep.data.data.releaseTime
             // this.detail.numbering = rep.data.data.numbering
            }
          }, (rep) =>{})
      },
      editRule(){
        this.isActive = true;
        this.isBorder = true;
        this.isHide = true;
        this.isShow = true;
      },
      saveEdit(){
        const that = this;
        //保存更改的信息
        //alert(that.detail.title);
      },
      canceled(){
        //this.$router.push("/rule-regulation-detail/"+this.detail.id)
        router.go(0);
      },
      change(){
        alert(1);
      }
    },
    components: {
    	crumbs,
    	card
    }
}
</script>

<style lang="sass" scoped>
.main{
  button{
    width: 75px;
    height: 40px;
    font-size: 16px;
    margin-top: -54px;
    margin-right: 30px;
  }
  .borderInput{
     border-color: #ccc !important;
  }
  .inputTitle{
    font-size: 16px;
    font-weight: bold;
    width: 50%;
  }
  .inputContent{
    width: 70%;
  }
  .inputContent,.inputTitle{
    display: block;
    min-height: 10px;
    _height: 10px;
    border: 1px solid #fff;
    margin: 20px;
    padding: 10px;
    outline: 0;
    word-wrap: break-word;
    overflow-x: hidden;
    overflow-y: auto;
    _overflow-y: visible;
  }
  .ruleBtn{
    margin: 20px;
    width: 70%;
    button{
      width: 100px;
      height: 40px;
      font-size: 16px;
      margin: 20px 10px 20px;
    }
    .btn-save{
      margin-left: 62%;
    }
  }
  .hidePart{
      display: none;
    }
    .showPart{
      display: block !important;
    }
}
</style>

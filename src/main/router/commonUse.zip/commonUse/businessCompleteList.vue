<template>

</template>

<script>
export default {
    name: 'businessCompleteList',
}
</script>

<style lang="sass" scoped>

</style>

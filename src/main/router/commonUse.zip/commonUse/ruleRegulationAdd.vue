<template>
    <div class="main">
    <crumbs v-bind:paths="paths"></crumbs>
    <card>
      <vEditDiv class="inputTitle" v-model="newRuleTitle"></vEditDiv>
      <div class="inputContent" contenteditable="true" ref="input1"></div>
      <div class="ruleBtn">
        <button class="btn btn-primary btn-save" type="button" @click="saveRule()">保存</button>
        <router-link to="/rule-regulation">
          <button class="btn btn-default" type="button">取消</button>
        </router-link>
      </div>
    </card>
    </div>
    </template>

    <script>
import axios from 'axios';
import qs from 'qs';
import router from '../index.js';

import vEditDiv from './component/vEditDiv.vue';
import crumbs from '../../component/crumbs.vue';
import card from '../../component/card.vue';

export default {
  name: 'ruleRegulationAdd',
  data(){
    return{
      paths: [
        { name: '制度列表', url: '/rule-regulation', present: false },
        { name: '录入制度', url: `/rule-regulation-add`, present: true }
      ],
      newRuleTitle: "",
      newRuleContent: "",
      input1: ""
    }
  },
  methods: {
    saveRule(){

    }
  },
  components: {
    crumbs,
    card,
    vEditDiv
  }
}
</script>

<style lang="sass" scoped>
.main{
.inputTitle {
    display: block;
    width: 50%;
  }
.inputContent{
    width: 70%;
  }
.inputTitle,.inputContent{
    min-height: 10px;
    _height: 10px;
    border: 1px solid #ccc;
    padding: 10px;
    margin: 20px;
    outline: 0;
    font-size: 14px;
    word-wrap: break-word;
    overflow-x: hidden;
    overflow-y: auto;
    _overflow-y: visible;
  }
.ruleBtn{
    width: 70%;
    margin: 20px;
    button{
      width: 100px;
      height: 40px;
      font-size: 16px;
      margin: 20px 10px 20px;
    }
  .btn-save{
      margin-left: 62%;
    }
  }
}
</style>
